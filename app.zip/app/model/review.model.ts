export interface Review {
    id: number;
    albumId: number; // Using definite assignment assertion
    title: string;
    body: string;
    rating: number;
  }
