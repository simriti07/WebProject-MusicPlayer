import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PlaylistService {
  songs: { name: string; url: string }[] = [
    { name: 'Perfect-Ed Sheeran', url: 'assets/audio/perfect.mp3' },
    { name: 'Lover-Taylor Swift', url: 'assets/audio/lover.mp3' },
    { name: 'Dynamite - BTS', url: 'assets/audio/dynamite.mp3' },
    { name: 'Girls-Black Pink', url: 'assets/audio/girls.mp3' },
    { name: 'Everyday-Ariana', url: 'assets/audio/everyday.mp3' },
    { name: 'Fri(END)s-BTS v', url: 'assets/audio/friends.mp3' },
  ];
  playlist: { name: string; url: string }[] = [];

  constructor() {}

  addToPlaylist(song: { name: string; url: string }) {
    this.playlist.push(song);
  }

  removeFromPlaylist(index: number) {
    this.playlist.splice(index, 1);
  }
}
