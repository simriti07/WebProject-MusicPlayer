import { Injectable } from '@angular/core';
import { NodeutilityService } from '../nodeutility.service';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MusicService {
  musicDatabase = [
    { name: 'Dynamite', singer: 'BTS', album: 'BE',src:'assets/audio/dynamite.mp3' },
    { name: 'Friends', singer: 'Anne Marie', album: 'Solo',src:'assets/audio/eng.mp3' },
    { name: 'Euphoria', singer: 'Jungkook-BTS', album: 'Map Soul 7' , src:'assets/audio/euphoria.mp3'},
    { name: 'Everyday', singer: 'Ariana Grande', album: 'Album4',src:'assets/audio/everyday.mp3' },
    { name: 'Fri(END)s', singer: 'V-BTS', album: 'Layo(v)er',src:'assets/audio/friends.mp3' },
    { name: 'Letter', singer: 'Jimin-BTS', album: 'Face',src:'assets/audio/letter.mp3' },
    { name: 'Paint the town Red', singer: 'Doja Cat', album: 'Solo',src:'assets/audio/paintred.mp3' },
    { name: 'Perfect', singer: 'Ed Sheeran', album: 'Solo',src:'assets/audio/perfect.mp3' },
    { name: 'Too Much', singer: 'Jungkook and Kid Lario', album: 'Solo',src:'assets/audio/toomuch.mp3' },
  ];
  private songAddedSubject = new Subject<any>();

  constructor(private util:NodeutilityService) { }

  getMusicDatabase() {
    return this.musicDatabase;
  }

  getSongAddedObservable() {
    return this.songAddedSubject.asObservable();
  }

  searchMusic(query: string) {
    query = query.toLowerCase();
    return this.musicDatabase.filter(music =>
      music.name.toLowerCase().includes(query) ||
      music.singer.toLowerCase().includes(query) ||
      music.album.toLowerCase().includes(query)
    );
  }

  // Add the new song to the music database and emit it through the songAddedSubject
  addSong(song: any) {
    this.musicDatabase.push(song);
    this.songAddedSubject.next(song);
    console.log('Song added to musicDatabase:', song);
    console.log( this.musicDatabase); // Log the added song data
  }
  
}
  

