import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowseCardComponent } from './components/browse-card/browse-card.component';
import { SongCardComponent } from './components/song-card/song-card.component';
import { TopNavComponent } from './components/top-nav/top-nav.component';
import { TopUnavComponent } from './components/top-unav/top-unav.component';
import { AboutComponent } from './pages/about/about.component';
import { AchangeComponent } from './pages/achange/achange.component';
import { AddsongComponent } from './pages/addsong/addsong.component';
import { AhomeComponent } from './pages/ahome/ahome.component';
import { AlogComponent } from './pages/alog/alog.component';
import { AprofComponent } from './pages/aprof/aprof.component';
import { AsignComponent } from './pages/asign/asign.component';
import { AviewComponent } from './pages/aview/aview.component';
import { Home1Component } from './pages/home1/home1.component';
import { PlaySongComponent } from './pages/play-song/play-song.component';
import { PlaylistComponent } from './pages/playlist/playlist.component';
import { RemoveComponent } from './pages/remove/remove.component';
import { ReviewComponent } from './pages/review/review.component';
import { SearchComponent } from './pages/search/search.component';
import { SongComponent } from './pages/song/song.component';
import { U1homeComponent } from './pages/u1home/u1home.component';
import { UchangeComponent } from './pages/uchange/uchange.component';
import { UhomeComponent } from './pages/uhome/uhome.component';
import { UlogComponent } from './pages/ulog/ulog.component';
import { UprofComponent } from './pages/uprof/uprof.component';
import { UsignComponent } from './pages/usign/usign.component';
import { ViewlistComponent } from './pages/viewlist/viewlist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NodeutilityService } from './nodeutility.service';
import { PageVisibilityService } from './services/PageVisibilityService';
import { AlwaysComponent } from './pages/always/always.component';

@NgModule({
  declarations: [
    AppComponent,
    BrowseCardComponent,
    SongCardComponent,
    TopNavComponent,
    TopUnavComponent,
    AboutComponent,
    AchangeComponent,
    AddsongComponent,
    AhomeComponent,
    AlogComponent,
    AprofComponent,
    AsignComponent,
    AviewComponent,
    Home1Component,
    PlaySongComponent,
    PlaylistComponent,
    RemoveComponent,
    ReviewComponent,
    SearchComponent,
    SongComponent,
    U1homeComponent,
    UchangeComponent,
    UhomeComponent,
    UlogComponent,
    UprofComponent,
    UsignComponent,
    ViewlistComponent,
    AlwaysComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    RouterModule,
    CommonModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [NodeutilityService,
    PageVisibilityService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
