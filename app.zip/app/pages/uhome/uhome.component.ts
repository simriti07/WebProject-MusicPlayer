import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PageVisibilityService } from 'src/app/services/PageVisibilityService';
import { SearchBarService } from 'src/app/services/searchbar.service';

@Component({
  selector: 'app-uhome',
  templateUrl: './uhome.component.html',
  styleUrls: ['./uhome.component.css']
})
export class UhomeComponent {
  public browserAll = [
    {
      bgColor: 'red',
      color: 'white',
      title: 'Podcasts',
    },
    { bgColor: 'green', color: 'white', title: 'Made for you' },
    { bgColor: 'purple', color: 'white', title: 'Charts' },
    { bgColor: 'blue', color: 'white', title: 'Live streams' },
    { bgColor: 'pink', color: 'white', title: 'Bollywood' },
    { bgColor: 'lightblue', color: 'white', title: 'Punjabi' },
    { bgColor: 'orange', color: 'white', title: 'Tamil' },
    { bgColor: 'yellow', color: 'white', title: 'Telugu' },
    { bgColor: 'black', color: 'white', title: 'Marathi' },
    { bgColor: 'orangered', color: 'white', title: 'Hip-Hop' },
    { bgColor: 'darkgray', color: 'white', title: 'Workout' },
    { bgColor: 'smokewhite', color: 'white', title: 'R&B' },
  ];
  public songCards = [
    {
      song_id: 1,
      thumbnail:
        'assets/img/kpop.png',
      title: 'Kpop :)',
      description: 'Bangtan,Blink,TxT...',
      song_link: 'assets/audio/dynamite.mp3',
    },
    {
      song_id: 2,
      thumbnail:
        'assets/img/peace.png',
      title: 'Peaceful Songs',
      description: 'Relax and enjoy the climate',
      song_link: 'assets/audio/perfect.mp3',
    },
    {
      song_id: 3,
      thumbnail:
        'assets/img/swift.png ',
      title: 'Swifte',
      description: 'Lets make the vibe with Taylor Swift',
      song_link: 'assets/audio/lover.mp3',
    },
    {
      song_id: 4,
      thumbnail:
        ' assets/img/ed.jpg',
      title: 'English Mashup',
      description: 'Party with Mashups :)',
      song_link: 'assets/audio/eng.mp3',
    },
    {
      song_id: 5,
      thumbnail:
        ' assets/img/tu.jpg',
      title: 'Spanish Songs',
      description: 'Live in the Delulu',
      song_link: 'assets/audio/spanish.mp3',
    },
    {
      song_id: 6,
      thumbnail:
      'assets/img/ost.png',
      title: 'K-ost',
      description: 'Live in the life as fantasy',
      song_link: 'assets/audio/friends.mp3',
    },
    {
      song_id: 7,
      thumbnail:
         'assets/img/sleep.png',
      title: 'Sleep ZZZ...',
      description: 'Relax and Rest in our own world',
      song_link: 'assets/audio/letter.mp3',
    },
    {
      song_id: 8,
      thumbnail:
        'assets/img/much.jpg ',
      title: 'Collaborations',
      description: 'Mix and get new',
      song_link: 'assets/audio/toomuch.mp3',
    },
    {
      song_id: 9,
      thumbnail:
        'assets/img/pop.jpg ',
      title: 'Pop',
      description: 'Area of vibzz',
      song_link: 'assets/audio/everyday.mp3',
    },
    {
      song_id: 10,
      thumbnail:
        'assets/img/blink.jpg ',
      title: 'Grls kpop',
      description: ' Pretty Savage',
      song_link: 'assets/audio/girls.mp3',
    },
    {
      song_id: 10,
      thumbnail:
        'assets/img/blink.jpg ',
      title: 'Grls kpop',
      description: ' Pretty Savage',
      song_link: 'assets/audio/girls.mp3',
    },
  ];

  constructor(public sb: SearchBarService,private router: Router,public pageVisibilityService: PageVisibilityService) {}
 

  ngOnInit(): void {}

 

  navigatetohome() {
    this.pageVisibilityService.showhome();
  }

  navigatetosearch() {
    this.pageVisibilityService.showsearch();
  }

  navigatetoreview() {
    this.pageVisibilityService.showreview();
  }

  navigatetolist() {
    this.pageVisibilityService.showlist();
  }

  navigatetoUChange() {
    this.pageVisibilityService.showUChange();
  }
}
