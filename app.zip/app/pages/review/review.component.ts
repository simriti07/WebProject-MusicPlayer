import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NodeutilityService } from 'src/app/nodeutility.service';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {
  rating: number = 0;
  stars: number[] = [1, 2, 3, 4, 5];
  reviewText: string = ''; // Add a property to hold the review text
  user1: string | null = '';
  constructor(private util: NodeutilityService, private router: Router) {}

  ngOnInit(): void {
    this.user1 = localStorage.getItem('user1');
  }

  rate(rating: number) {
    this.rating = rating;
    console.log('Rating:', this.rating);
  }

  submitReview(form: any) {
    // Assign the value of the review text input to the reviewText property
    this.reviewText = form.value.reviewText;

    // Here you can implement the logic to submit the review
    console.log('Review Rating:', this.rating);
    console.log('Review Text:', this.reviewText);
    if(this.user1===form.value.email){
    this.util.insert4(form.value.email, this.reviewText, this.rating).subscribe((data: any) => {
      if (data.status) {
        alert(data.message); // Show alert on success
        this.router.navigate(['/']); // Navigate to home or wherever after successful submission
      } else {
        alert("Failed to insert review. Please try again."); // Show alert on failure
      }
    }, (error: any) => {
      console.error("Error inserting review:", error);
      alert("Review added succesfully"); // Show alert on error
    });
  }
  else{
    alert("Enter correct username");
  }
}
}
