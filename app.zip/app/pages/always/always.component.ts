import { Component } from '@angular/core';

@Component({
  selector: 'app-always',
  templateUrl: './always.component.html',
  styleUrls: ['./always.component.css']
})
export class AlwaysComponent {

}
