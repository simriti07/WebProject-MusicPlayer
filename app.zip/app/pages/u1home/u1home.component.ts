import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PageVisibilityService } from 'src/app/services/PageVisibilityService';

@Component({
  selector: 'app-u1home',
  templateUrl: './u1home.component.html',
  styleUrls: ['./u1home.component.css']
})
export class U1homeComponent {
  constructor(private router: Router,public pageVisibilityService: PageVisibilityService) {}
 

  ngOnInit(): void {}

  

  navigatetohome() {
    this.pageVisibilityService.showhome();
  }

  navigatetosearch() {
    this.pageVisibilityService.showsearch();
  }

  navigatetoreview() {
    this.pageVisibilityService.showreview();
  }

  navigatetolist() {
    this.pageVisibilityService.showlist();
  }

  navigatetoUChange() {
    this.pageVisibilityService.showUChange();
  }
}
