import { Component } from '@angular/core';
import { PlaylistService } from 'src/app/services/playlist.service';

@Component({
  selector: 'app-play-song',
  templateUrl: './play-song.component.html',
  styleUrls: ['./play-song.component.css']
})
export class PlaySongComponent {
  currentSong!: { name: string; url: string };
  isPlaying: boolean = false;
  audioPlayer: HTMLAudioElement = new Audio();

  constructor(private playlistService: PlaylistService) {}

  ngOnInit(): void {
    this.currentSong = this.playlistService.playlist[0] || { name: '', url: '' }; // Initialize with the first song or empty object
    this.audioPlayer.src = this.currentSong.url;
  }

  play() {
    this.audioPlayer.play();
    this.isPlaying = true;
  }

  pause() {
    this.audioPlayer.pause();
    this.isPlaying = false;
  }

  skip() {
    const currentIndex = this.playlistService.playlist.indexOf(this.currentSong);
    const nextIndex = (currentIndex + 1) % this.playlistService.playlist.length;
    this.currentSong = this.playlistService.playlist[nextIndex];
    this.audioPlayer.src = this.currentSong.url;
    this.play();
  }
}
