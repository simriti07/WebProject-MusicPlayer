import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { PageVisibilityService } from 'src/app/services/PageVisibilityService';
import { MusicService } from 'src/app/services/music.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnDestroy {
  searchQuery: string = '';
  searchResults: any[] = [];
  currentMusic: any = null;
  audioPlayer: any = new Audio();
  isPaused: boolean = false;

  private songAddedSubscription!: Subscription; 

  constructor(private musicService: MusicService, private pageVisibilityService: PageVisibilityService) {
    this.songAddedSubscription = this.musicService.getSongAddedObservable().subscribe(() => {
      this.search();
    });
  }

  ngOnDestroy() {
    this.songAddedSubscription.unsubscribe();
  }

  search() {
    this.searchResults = this.musicService.searchMusic(this.searchQuery);
  }

  playMusic(music: any) {
    this.currentMusic = music;
    this.audioPlayer.src = this.currentMusic.src;
    if (!this.isPaused) {
      this.audioPlayer.play();
    }
    this.isPaused = false;
  }

  pauseMusic() {
    if (this.audioPlayer.paused) {
      this.audioPlayer.play();
      this.isPaused = false;
    } else {
      this.audioPlayer.pause();
      this.isPaused = true;
    }
  }
}
