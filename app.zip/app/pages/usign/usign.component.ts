import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NodeutilityService } from 'src/app/nodeutility.service';

@Component({
  selector: 'app-usign',
  templateUrl: './usign.component.html',
  styleUrls: ['./usign.component.css']
})
export class UsignComponent implements OnInit {
  public usernameFormControl = new FormControl(null, [Validators.required, Validators.email]);
  public phnoFormControl = new FormControl(null, [Validators.minLength(10), Validators.maxLength(10)]);
  public passwordFormControl = new FormControl(null, [Validators.minLength(6)]);
  public confirmPasswordFormControl = new FormControl(null, [Validators.minLength(6)]);

  public userForm!: FormGroup;
  msg: string = '';
  username: string = '';
  phno: string = '';
  pw: string = '';
  pmm: boolean = false;

  constructor(private util: NodeutilityService, private router: Router) { }

  ngOnInit(): void {
    this.userForm = new FormGroup({
      username: this.usernameFormControl,
      phno: this.phnoFormControl,
      password: this.passwordFormControl,
      confirmPassword: this.confirmPasswordFormControl // Adding confirmPassword to the form group
    });

    // Listen for changes in confirmPassword field
    this.confirmPasswordFormControl.valueChanges.subscribe(() => {
      this.validatePasswordMatch();
    });
  }

  onSubmit(form: any) {
    if (this.userForm.valid && !this.pmm) {
      const username = this.userForm.value.username;
      const phno = this.userForm.value.phno;
      const password = this.userForm.value.password;
      const cpassword = this.userForm.value.confirmPassword;

      this.util.checkUnameAvailability(username).subscribe(
        (data: any) => {
          if (!data.available) {
            alert("Email is already registered");
          } else {
            this.util.insert1(username, phno, password, cpassword).subscribe(
              (insertData: any) => {
                if (insertData.status) {
                  this.msg = insertData.message;
                  if (password === cpassword) {
                    alert(this.msg);
                    this.router.navigate(['/ulog']);
                  } else {
                    alert("Registration Failed, please verify the values");
                  }

                } else {
                  console.error("Insertion failed:", insertData.message);

                  // Handle insertion failure appropriately
                }
              },
              (insertError) => {
                console.error("Error inserting data:", insertError);
                alert("Error inserting data. Please try again.");
              }
            );
          }
        },
        (checkError) => {
          console.error("Error checking email availability:", checkError);
          alert("Email is already registered. Please try again.");
        }
      );
    } else {
      alert("Please fix validation errors before submitting.");
    }
  }

  // Custom method to validate password match
  validatePasswordMatch() {
    const password = this.userForm.get('password')?.value;
    const confirmPassword = this.userForm.get('confirmPassword')?.value;
    if (password !== confirmPassword) {
      this.pmm = true;
    } else {
      this.pmm = false;
    }
  }
}
