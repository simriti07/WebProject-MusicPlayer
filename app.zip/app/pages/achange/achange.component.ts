import { Component } from '@angular/core';

@Component({
  selector: 'app-achange',
  templateUrl: './achange.component.html',
  styleUrls: ['./achange.component.css']
})
export class AchangeComponent {

}
