import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TopUnavComponent } from './top-unav.component';

describe('TopUnavComponent', () => {
  let component: TopUnavComponent;
  let fixture: ComponentFixture<TopUnavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TopUnavComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TopUnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
